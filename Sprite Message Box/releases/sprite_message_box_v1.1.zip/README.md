# SMW-Patches
A bunch of patches that I've converted or fixed.
