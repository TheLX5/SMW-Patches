# Shared Code
A library of shared functions and macros that are often useful and are used in most of my patches.
